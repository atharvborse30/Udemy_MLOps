from flask import Flask

'''
    It creates an instance of the Flask class,
    which will be your WSGI (web server gateway interface) application.
'''

app = Flask(__name__)

@app.route("/")
def welcome():
    return "Welcome to the Flask"

@app.route("/index")
def index():
    return "Index Page"


if __name__ == "__main__":
    app.run(debug=True)    # debug = True lets us to autosave/reload the webserver, it saves our time to rerun the command s