from flask import Flask, render_template

# render_template - is responsible in redirecting that particular page
'''
    It creates an instance of the Flask class,
    which will be your WSGI (web server gateway interface) application.
'''

app = Flask(__name__)

@app.route("/")
def welcome():
    return "<html><H1>Welcome to Flask</H1></html>"

@app.route("/index")
def index():
    return render_template('index.html')

@app.route("/about")
def about():
    return render_template('about.html')


if __name__ == "__main__":
    app.run(debug=True)    # debug = True lets us to autosave/reload the webserver, it saves our time to rerun the command s